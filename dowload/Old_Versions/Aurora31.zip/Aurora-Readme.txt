Aurora download - NEW !!!! - Aurora 3.1 released!

In this directory the whole set of Aurora plug-ins for CoolEdit
is stored. The plug-ins are in the ZIP files called AURORA31.zip 
(Aurora 3.1, released on 8/1/2000). 
No installation procedure is required: simply copy the contents of the
ZIP file within the directory where the CoolEdit Program was installed.
If CoolEdit seems to not recognize the new modules, simply destroy
the files called XFM.DAT and FLT.DAT. At the subsequent launch, CoolEdit
will scan for new plug-ins and recreate the above two files.

Registration of Aurora plug-ins.
These plugins are not registered, You can use them only for evaluation.
If You want to register, please wait until the new publisher (KAGI.COM) 
is ready to accept on-line registration.
The unregistered plug-ins are fully functional, but they exhibit an 
annoying behaviour. Randomly (with a chance of 1:4) they crash CoolEdit!
Of course, after registration this annoying behaviour disappears...

Self-Registration of Aurora 3.1 plugins
The new release of Aurora 3.1 introduces self-registration of the
plugins. If You received Your username and reg.key from Acoustec, simply
create a text file called AuroKey.txt, containing in the first line
Your username, and the reg.key in the second line. Save this file in any 
directory in your PATH (i.e. C:\Windows). Then destroy the file XFM.DAT
in the CoolEdit directory, so that CoolEdit is forced to re-inizialize
the plugins at the next start. Each plugin will search for the AuroKey.txt
file, and if found will read automatically the reg.info from it.

Help Files
The help files and the manual included are out-of-date with the
current development of plug-ins. In a month or so 
the new, updated help files, in English, will be available on this site.
In the meanwhile, please refer to the Aurora web pages for explanations.

Enjoy it!

Angelo Farina