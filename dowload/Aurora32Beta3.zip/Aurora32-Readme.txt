Aurora download - NEW !!!! - Aurora 3.2 released!

*** Beta 3 main improvements ***
1) All the modules now respond to CoolEdit with XFMValidLibrary=1157, which enables
them to work both under CoolEditPro and CoolEdit2000. The support for Cool96 is
no more available.
2) Improved robustness of all the modules, except for Real Time Convolver, who still
crashes after too many button pressures on the module's interface.

*** Beta 2 main improvements ***
1) Now Calculate Acoustics has a beatiful graphical interface for displaying
the Impulse Response (in dB scale) superposed with the Schroeder plot. It is
possible to display how the impulse response changes when filtered in each
octave band.
2) Now also Signal and Noise level are shown. The value is expressed in terms
of SEL (Single Event Level), and thus represent the total energy of the 
Impulse Response. This value corresponds with teh starting point of the
Schroeder plot. Instead, the Impulse Response plot is scaled in 
"Instantaneous dB", with an RMS integration time equal to 1/500 of the
Impulse Response length
3) The new parameter Strength is computed. This requires that a reference
free-field impulse response has been previously stored as reference level.
4) The Invert Kirkeby module now also supports a simplified Cross-talk cancel
only mode, (from an original idea of Ralph Glasgal), which computes cross
talk cancelling filters without any equalization on the ipselateral paths.
5) The MLSSA tim filter now maintains 32-bits depth also during the export.

*** Aurora 3.2 BETA main improvements ***
1) All the modules now are compliant with 32-bit waveform processing, without
any intermediate reduction to 16 bits during data transfers between CoolEdit
and the plugins. This results in improved dynamic range and reduced computational
noise.
2) Some minor bugs have been corrected in many modules.
3) The new module ConvoWarp has been added, implementing WFIR processing (Warped
Finite Impulse Response filtering). Also cross-talk cancelling networks, with 4
separate filters (in the 2x2 format) are accepted.
4) The Invert Kirkeby module now accepts the computation of filters shorter than
the original impulse responses to invert. This has been done with the new Mourjopoulos
formulation of frequency-domain smoothing (AES Journal, March 2000), which indirectly
causes the computation of the inverse filters to be made with an algorithm which is
substantially different from the original Nelson-Kirkeby formulation, because now not
only the regularization parameter is variable with frequency, but also the equivalent
bandwidth of each spectral line is variable with approximate logarithmic law.


*** Setup Instructions ***

In this directory the whole set of Aurora plug-ins for CoolEdit
is stored. The plug-ins are in the ZIP files called AURORA32BETA2.zip 
(Aurora 3.2 Beta2, released on 06/september/2000). 
No installation procedure is required: simply copy the contents of the
ZIP file within the directory where the CoolEdit Program was installed.
If CoolEdit seems to not recognize the new modules, simply destroy
the files called XFM.DAT and FLT.DAT. At the subsequent launch, CoolEdit
will scan for new plug-ins and recreate the above two files.

Registration of Aurora plug-ins.
These plugins are not registered, You can use them only for evaluation.
If You want to register, please contact the new publisher (KAGI.COM) 
who is now ready to accept on-line registration.
The unregistered plug-ins are fully functional, but they exhibit an 
annoying behaviour. Randomly (with a chance of 1:4) they crash CoolEdit!
Of course, after registration this annoying behaviour disappears...

Self-Registration of Aurora 3.2 plugins
The new release of Aurora 3.2 introduces self-registration of the
plugins. If You received Your username and reg.key from Acoustec, simply
create a text file called AuroKey.txt, containing in the first line
Your username, and the reg.key in the second line. Save this file in any 
directory in your PATH (i.e. C:\Windows). Then destroy the file XFM.DAT
in the CoolEdit directory, so that CoolEdit is forced to re-inizialize
the plugins at the next start. Each plugin will search for the AuroKey.txt
file, and if found will read automatically the reg.info from it.

Aurora 3.2 single-plugin self registration
If You only purchased some of the 16 plugins, You will receive a separate 
TXT file for each plugin (acoustic.txt, convolv.txt, etc.). AGain, You need
to copy all these files in a directory included in Your PATH string.

Help Files
The help files and the manual included are out-of-date with the
current development of plug-ins. Together with the official release of
Aurora 3.2 (scheduled for 30th September 2000), updated help files, in English, 
will be available on this site.
For the manual a couple of months more will be required...
In the meanwhile, please refer to the Aurora web pages for explanations.

Enjoy it!

Angelo Farina